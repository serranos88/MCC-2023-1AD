public class Word {
    
}
