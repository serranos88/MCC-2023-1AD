public class App {
    public static void main(String[] args) throws Exception {
        Input in = new Input("C:\\Users\\josek\\Documents\\gitMCC\\MCC-2023-1AD\\kwic\\src\\palabras.txt");
        //Input in = new Input("C:\\Users\\josek\\Documents\\gitMCC\\MCC-2023-1AD\\kwic\\src\\palabras2.txt");
        //Input in = new Input("C:\\Users\\josek\\Documents\\gitMCC\\MCC-2023-1AD\\kwic\\src\\palabras3.txt");
        //Input in = new Input("C:\\Users\\josek\\Documents\\gitMCC\\MCC-2023-1AD\\kwic\\src\\palabras4.txt");

        

        in.leerTexto();
        CircularShifter shifter = new CircularShifter();
        shifter.setup();

        Sort sort = new Sort();
        sort.alfabeticamente();
        
        Output output = new Output();
        output.imprimir();



    }
}
