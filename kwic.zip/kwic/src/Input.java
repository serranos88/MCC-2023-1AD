import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class Input {
    private final String RUTA; 
    
    private Characters oraciones;
    

    public Input(String ruta) {
        this.oraciones = new Characters();
        this.RUTA = ruta;
    }

    public void leerTexto() {
        try (BufferedReader bf = new BufferedReader(new FileReader(RUTA))) {
            String s;
            while ((s = bf.readLine()) != null) {
                if (!s.trim().isEmpty()) {
                    oraciones.setChar(s);
                }
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    

    public static void imprimirOraciones(ArrayList<String> lista) {
        for (String linea : lista) {
            System.out.println(linea);
        }
    }

    /* 
    public ArrayList<String> getOraciones() {
        return oraciones;
    }*/
}

