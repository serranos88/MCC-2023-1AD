import java.util.ArrayList;

public class Sort {

    private static ArrayList<String> oracionesOrdenadas;
    private static ArrayList<String> oracionesRotadas;

    public Sort() {
        oracionesOrdenadas = new ArrayList<>();
        oracionesRotadas = CircularShifter.getOracionesRotadas();
    }

    public void alfabeticamente() {
        oracionesOrdenadas = sort(oracionesRotadas);
    }

    public static ArrayList<String> sort(ArrayList<String> informacion) {
        // Ordenar el ArrayList alfabeticamente
        oracionesOrdenadas = new ArrayList<>(informacion);
        //Collections.sort(oracionesOrdenadas, String.CASE_INSENSITIVE_ORDER);
        bubbleSort(oracionesOrdenadas);
        // Retorna el ArrayList ordenado
        return oracionesOrdenadas;
    }

    // Metodo get para obtener el ArrayList ordenado
    public static ArrayList<String> getOracionesOrdenadas() {
        return oracionesOrdenadas;
    }

    private static void bubbleSort(ArrayList<String> informacion) {
        int n = informacion.size();
        String aux;
        for (int i = 0; i < n; i++) {
            for (int j = 1; j < (n - i); j++) {
                if (informacion.get(j - 1).compareToIgnoreCase(informacion.get(j)) > 0) {
                    aux = informacion.get(j - 1);
                    informacion.set(j - 1, informacion.get(j));
                    informacion.set(j, aux);
                }
            }
        }
    }
}
